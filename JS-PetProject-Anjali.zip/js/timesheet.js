// empty array to hold timesheet data
let timesheetData = [];

// Function to add a row to the timesheet table
function addRow() {
    // Get values from input fields
    let name = document.getElementById("name").value;
    let course = document.getElementById("course").value;
    let activity = document.getElementById("activity").value;
    let date = document.getElementById("date").value;
    let time = document.getElementById("time").value;
    let notes = document.getElementById("notes").value;

    // Create new row in timesheet table
    let table = document.getElementById("timesheet");
    let row = table.insertRow();
    let week = getWeek(date);
    // i have used $ sign of jquery at some places instead of using document.getElementByID.
    row.innerHTML = `
		<td>${week}</td>
		<td>${name}</td>
		<td>${course}</td>
		<td>${activity}</td>
		<td>${date}</td>
		<td>${time}</td>
		<td>${notes}</td>
	`;

    // Add data to timesheetData array
    timesheetData.push({
        week: week,
        name: name,
        course: course,
        activity: activity,
        date: date,
        time: time,
        notes: notes
    });
}

// Function to calculate total time for each week
function calculateTotal() {
    //empty object to hold total time data
    let totalTimeData = {};

    // Loop through timesheetData array and sum time for each week
    timesheetData.forEach(row => {
        if (row.week in totalTimeData) {
            totalTimeData[row.week] += parseInt(row.time);
        } else {
            totalTimeData[row.week] = parseInt(row.time);
        }
    });

    // Create new rows in total time table
    let table = document.getElementById("totals");
    let tbody = table.getElementsByTagName("tbody")[0];
    tbody.innerHTML = "";
    for (let week in totalTimeData) {
        let row = tbody.insertRow();
        row.innerHTML = `
			<td>${week}</td>
			<td>${totalTimeData[week]}</td>
		`;
    }
}

// Function to print timesheet
function printTimesheet() {
    window.print();
}

// Helper function to get week number from date
function getWeek(date) {
    let d = new Date(date);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
    let yearStart = new Date(d.getFullYear(), 0, 1);
    let weekNo = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
    return weekNo;
}
